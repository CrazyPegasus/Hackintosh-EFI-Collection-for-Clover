# Hackintosh-EFI-For-ASUS-B150M-A-m.2
本人的黑果EFI文件，用做备份。
最后更新：2017-10-05
